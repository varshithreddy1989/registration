package com.org.app.registration.junit;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.UUID;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import com.org.app.registration.beans.RegistrationDetails;

public class TestClass {

	@Autowired
	private TestRestTemplate restTemplate;
	private final HttpHeaders headers = new HttpHeaders();
	private final String registrationURL = "";

	@Test
	public void greetingShouldReturnDefaultMessage() throws Exception {
		RegistrationDetails registrationDetails = new RegistrationDetails();
		registrationDetails.setUsername("username");
		registrationDetails.setPassword("Java2blog_");
		registrationDetails.setIpAddress("69.39.84.205");

		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> request = new HttpEntity<String>(registrationDetails.toString(), headers);
		String responseUUID = restTemplate.postForObject(registrationURL, request, String.class);
		System.out.println(responseUUID);
		assertThat(UUID.fromString(responseUUID));
	}
}
