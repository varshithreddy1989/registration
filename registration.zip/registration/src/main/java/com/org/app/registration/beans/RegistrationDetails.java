package com.org.app.registration.beans;

import javax.validation.constraints.NotEmpty;

public class RegistrationDetails {

	@NotEmpty(message = "UserName is mandatory")
	private String username;

	@NotEmpty(message = "Password is mandatory")
	private String password;

	@NotEmpty(message = "IPAddress is mandatory")
	private String ipAddress;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

}
