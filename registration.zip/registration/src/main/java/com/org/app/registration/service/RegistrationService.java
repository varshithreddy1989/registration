package com.org.app.registration.service;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;

import com.org.app.registration.beans.RegistrationDetails;
import com.org.app.registration.validation.RegistrationValidator;

public class RegistrationService {

	@Autowired
	RegistrationValidator registrationValidator;

	public String registerUser(RegistrationDetails registrationDetails) {
		String password = registrationDetails.getPassword();
		String ipAddress = registrationDetails.getIpAddress();

		if (registrationValidator.validatePassword(password)) {

		}
		if (registrationValidator.validateIpAddress(ipAddress)) {

		}

		String uuid = UUID.randomUUID().toString();
		return uuid;
	}
	
	
	public static void main(String[] args) {
		
	}
}