package com.org.app.registration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.org.app.registration.beans.RegistrationDetails;
import com.org.app.registration.service.RegistrationService;

@RestController
@RequestMapping(value = "", produces = MediaType.APPLICATION_JSON_VALUE)
@ComponentScan(value = "com.org.app.registration.*")
public class RegistrationController {

	@Autowired
	RegistrationService service;

	@RequestMapping(value = { "v1/app/registration" }, method = RequestMethod.POST)
	public String orgLocationCompilePrices(@RequestBody(required = true) RegistrationDetails registrationDetails) {
		return service.registerUser(registrationDetails);
	}

	@RequestMapping(value = { "/alive" }, method = RequestMethod.GET)
	public HttpStatus healthCheck() {
		return HttpStatus.OK;
	}
}