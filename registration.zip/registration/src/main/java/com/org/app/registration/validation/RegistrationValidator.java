package com.org.app.registration.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.org.app.registration.beans.IPAddressBean;

public class RegistrationValidator {

	static String URL = "http://ip-api.com/json/";

	public boolean validateIpAddress(String ipAddress) {
		RestTemplate restTemplate = new RestTemplate();
		URL = URL + ipAddress;
		ResponseEntity<IPAddressBean> responseEntity = restTemplate.exchange(URL, HttpMethod.GET, null,
				new ParameterizedTypeReference<IPAddressBean>() {
				});
		IPAddressBean ipAddressBean = responseEntity.getBody();
		if (!ipAddressBean.getCountry().equals("Canada")) {
			return false;
		}
		return true;
	}

	public boolean validatePassword(String password) {
		String regex = "^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[_#$%.]).{8,}$";
		if (isValidPassword(password, regex))
			return true;
		return false;

	}

	public static boolean isValidPassword(String password, String regex) {
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(password);
		return matcher.matches();
	}
}